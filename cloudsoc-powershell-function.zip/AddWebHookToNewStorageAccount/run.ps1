param($eventGridEvent, $TriggerMetadata)
$webhook = "" #Todo: add web hook from azure connection powershell file
$token = "" #Todo: add toke from azure connection  
$event_sub_name = "CloudSocStorageEvent"
Write-Host "*****************"
$eventGridEvent.Keys.ForEach({"$_ $($eventGridEvent.$_)"}) -join ' | '
Write-Host "*****************"
$eventGridEvent.data.Keys.ForEach({"$_ $($eventGridEvent.data.$_)"}) -join ' | '
Write-Host "*****************"
# Make sure to pass hashtables to Out-String so they're logged correctly
if ($eventGridEvent.data.operationName -eq "Microsoft.Storage/storageAccounts/write" -and $eventGridEvent.data.status -eq "Succeeded")
{   
    $resourceUri = $eventGridEvent.data.resourceUri
    $includedEventTypes = "Microsoft.Storage.BlobCreated", "Microsoft.Storage.BlobDeleted"
    $bearer_token = "Bearer " + $token 

    $DeliveryAttributeMapping1=@{Name="Authorization"; Type="Static"; Value=$bearer_token ; IsSecret="true"}
    $DeliveryAttributeMapping=@($DeliveryAttributeMapping1)
    Write-Host "*******Invoke**********"
    $result = New-AzEventGridSubscription -ResourceId $resourceUri -Endpoint $webhook -IncludedEventType $includedEventTypes -DeliveryAttributeMapping $DeliveryAttributeMapping -EventSubscriptionName $event_sub_name 
    Write-Host $result
    Write-Host "*******Invoke-End**********"
}

